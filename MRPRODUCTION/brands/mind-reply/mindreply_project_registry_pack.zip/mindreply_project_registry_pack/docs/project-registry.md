# MindReply Project Registry

Security-first 40-project registry scaffold.

## Main Website
- ID: `main-website`
- Category: `public_site`
- Status: `READY`
- Public route: `/`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `True`

## ReplyControl
- ID: `replycontrol`
- Category: `revenue_offer`
- Status: `READY`
- Public route: `/replycontrol`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `True`

## Follow-Up Control
- ID: `follow-up-control`
- Category: `revenue_offer`
- Status: `READY`
- Public route: `/follow-up-control`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `True`

## Communication Audit
- ID: `communication-audit`
- Category: `revenue_offer`
- Status: `READY`
- Public route: `/communication-audit`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `True`

## Owner Cockpit
- ID: `owner-cockpit`
- Category: `owner_dashboard`
- Status: `DEMO_ONLY`
- Public route: `/owner-cockpit`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `False`

## Proof Dashboard
- ID: `proof-dashboard`
- Category: `proof_dashboard`
- Status: `DEMO_ONLY`
- Public route: `/proof-dashboard`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `True`

## Project Outcomes
- ID: `project-outcomes`
- Category: `documentation`
- Status: `READY`
- Public route: `/project-outcomes`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `True`

## Action Center
- ID: `action-center`
- Category: `owner_dashboard`
- Status: `DEMO_ONLY`
- Public route: `/action-center`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `False`

## Operator System
- ID: `operator-system`
- Category: `operator_system`
- Status: `READY`
- Public route: `/operator-system`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `True`

## Status Page
- ID: `status-page`
- Category: `documentation`
- Status: `READY`
- Public route: `/status`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `True`

## Pricing Page
- ID: `pricing-page`
- Category: `revenue_offer`
- Status: `READY`
- Public route: `/pricing`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `True`

## Contact Page
- ID: `contact-page`
- Category: `public_site`
- Status: `READY`
- Public route: `/contact`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `True`

## Decision Engine
- ID: `decision-engine`
- Category: `decision_system`
- Status: `PARTIAL`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `documentation_only`
- Safe to preview: `False`

## Daily Operator Brief
- ID: `daily-operator-brief`
- Category: `decision_system`
- Status: `DEMO_ONLY`
- Public route: `/weekly-command-brief`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `False`

## Risk Guard
- ID: `risk-guard`
- Category: `decision_system`
- Status: `PARTIAL`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `documentation_only`
- Safe to preview: `False`

## Error Center
- ID: `error-center`
- Category: `admin_tool`
- Status: `PARTIAL`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `documentation_only`
- Safe to preview: `False`

## Rollback Center
- ID: `rollback-center`
- Category: `deployment_tool`
- Status: `PARTIAL`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `documentation_only`
- Safe to preview: `False`

## Improvement Queue
- ID: `improvement-queue`
- Category: `decision_system`
- Status: `PARTIAL`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `documentation_only`
- Safe to preview: `False`

## Lead Capture
- ID: `lead-capture`
- Category: `data_layer`
- Status: `NEEDS_CONNECTION`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_d1_later`
- Safe to preview: `False`

## Revenue Opportunities
- ID: `revenue-opportunities`
- Category: `data_layer`
- Status: `NEEDS_CONNECTION`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_d1_later`
- Safe to preview: `False`

## Audit Log
- ID: `audit-log`
- Category: `data_layer`
- Status: `NEEDS_CONNECTION`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_d1_later`
- Safe to preview: `False`

## Build Status
- ID: `build-status`
- Category: `deployment_tool`
- Status: `PARTIAL`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `documentation_only`
- Safe to preview: `False`

## Browser Extension
- ID: `browser-extension`
- Category: `browser_extension`
- Status: `UNVERIFIED`
- Public route: `None`
- Repo strategy: `split_to_new_repo_later`
- Deployment strategy: `extension_later`
- Safe to preview: `False`

## AI Gateway
- ID: `ai-gateway`
- Category: `backend_service`
- Status: `UNVERIFIED`
- Public route: `None`
- Repo strategy: `split_to_new_repo_later`
- Deployment strategy: `worker_later`
- Safe to preview: `False`

## Backend API
- ID: `backend-api`
- Category: `backend_service`
- Status: `PARTIAL`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_workers_later`
- Safe to preview: `False`

## Admin Dashboard
- ID: `admin-dashboard`
- Category: `admin_tool`
- Status: `DEMO_ONLY`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `auth_required_later`
- Safe to preview: `False`

## Automation Specs
- ID: `automation-specs`
- Category: `automation`
- Status: `READY`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `documentation_only`
- Safe to preview: `False`

## Deployment Scripts
- ID: `deployment-scripts`
- Category: `deployment_tool`
- Status: `UNVERIFIED`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `security_review_first`
- Safe to preview: `False`

## GitHub Actions
- ID: `github-actions`
- Category: `deployment_tool`
- Status: `UNVERIFIED`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `security_review_first`
- Safe to preview: `False`

## Cloudflare Deployment
- ID: `cloudflare-deployment`
- Category: `deployment_tool`
- Status: `READY`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `cloudflare_pages`
- Safe to preview: `False`

## Data Models
- ID: `data-models`
- Category: `data_layer`
- Status: `READY`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `documentation_only`
- Safe to preview: `False`

## Security Docs
- ID: `security-docs`
- Category: `documentation`
- Status: `READY`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `documentation_only`
- Safe to preview: `False`

## Multi-Site Pack
- ID: `multi-site-pack`
- Category: `archive_candidate`
- Status: `UNVERIFIED`
- Public route: `None`
- Repo strategy: `archive_later`
- Deployment strategy: `do_not_deploy`
- Safe to preview: `False`

## Old 18-Site Ecosystem
- ID: `old-18-site-ecosystem`
- Category: `archive_candidate`
- Status: `UNVERIFIED`
- Public route: `None`
- Repo strategy: `archive_later`
- Deployment strategy: `do_not_deploy`
- Safe to preview: `False`

## Owner Command Console
- ID: `owner-command-console`
- Category: `owner_dashboard`
- Status: `PARTIAL`
- Public route: `None`
- Repo strategy: `merge_candidate`
- Deployment strategy: `cloudflare_pages_later`
- Safe to preview: `False`

## Self-Healing Issue Engine
- ID: `self-healing-issue-engine`
- Category: `automation`
- Status: `UNVERIFIED`
- Public route: `None`
- Repo strategy: `merge_candidate`
- Deployment strategy: `security_review_first`
- Safe to preview: `False`

## Visual Direction Engine
- ID: `visual-direction-engine`
- Category: `documentation`
- Status: `PARTIAL`
- Public route: `None`
- Repo strategy: `merge_candidate`
- Deployment strategy: `documentation_only`
- Safe to preview: `False`

## Product Docs
- ID: `product-docs`
- Category: `documentation`
- Status: `READY`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `documentation_only`
- Safe to preview: `False`

## Archive Candidates
- ID: `archive-candidates`
- Category: `archive_candidate`
- Status: `PARTIAL`
- Public route: `None`
- Repo strategy: `archive_later`
- Deployment strategy: `do_not_deploy`
- Safe to preview: `False`

## Repo Strategy
- ID: `repo-strategy`
- Category: `documentation`
- Status: `READY`
- Public route: `None`
- Repo strategy: `keep_in_main_repo`
- Deployment strategy: `documentation_only`
- Safe to preview: `False`
