# MindReply Project Registry Pack

This pack contains:

- `data/project-registry.json` — 40-project registry scaffold
- `automation-specs/automation-plan.json` — safe automation workflow specs
- `scripts/update_project_registry.py` — local scanner/report generator
- `docs/project-registry.md` — human-readable registry summary

Security posture:

- No secrets included.
- No webhook URLs included.
- No third-party builder dependency.
- Owner approval required before production, deletion, external messaging, payments, DNS, or secret changes.
