#!/usr/bin/env python3
"""
MindReply Project Registry Automation
Security-first local script. It scans selected repo folders, updates registry status hints,
and writes public-safe reports. It does not delete files, deploy production, or expose secrets.
"""
import json, os, re, datetime
from pathlib import Path

ROOT = Path.cwd()
REGISTRY_PATH = ROOT / "data" / "project-registry.json"
REPORT_PATH = ROOT / "docs" / "project-registry-report.md"
SENSITIVE_PATTERNS = [
    re.compile(r"(?i)(api[_-]?key|secret|token|webhook|private[_-]?key|password)\s*[:=]\s*['\"]?[^'\"\s]+"),
    re.compile(r"https://[^\s]+webhook[^\s]*", re.I),
]
SCAN_DIRS = ["app", "apps", "automation", "backend", "browser-extension", "dashboard", "docs", "frontend", "lib", "n8n", "public", "scripts", "services"]

def hide_sensitive(text):
    for pat in SENSITIVE_PATTERNS:
        text = pat.sub(lambda m: m.group(0).split(":")[0].split("=")[0] + ": value hidden", text)
    return text

def path_exists_hint(slug):
    matches = []
    for folder in SCAN_DIRS:
        p = ROOT / folder
        if not p.exists():
            continue
        for child in p.rglob("*"):
            rel = str(child.relative_to(ROOT)).lower()
            if slug.lower() in rel:
                matches.append(str(child.relative_to(ROOT)))
                if len(matches) >= 5:
                    return matches
    return matches

def main():
    if not REGISTRY_PATH.exists():
        raise SystemExit(f"Missing {REGISTRY_PATH}")
    registry = json.loads(REGISTRY_PATH.read_text(encoding="utf-8"))
    now = datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"
    for project in registry.get("projects", []):
        hints = path_exists_hint(project["slug"])
        if hints:
            project["source_location"] = hints[0]
            project["discovered_paths"] = hints
            if project["current_status"] == "UNVERIFIED":
                project["current_status"] = "PARTIAL"
        else:
            project["discovered_paths"] = []
    registry["last_scanned_at"] = now
    REGISTRY_PATH.write_text(json.dumps(registry, indent=2, ensure_ascii=False), encoding="utf-8")

    lines = ["# MindReply Project Registry Report", "", f"Generated: {now}", ""]
    for p in registry["projects"]:
        lines += [
            f"## {p['name']}",
            f"- Status: {p['current_status']}",
            f"- Category: {p['category']}",
            f"- Public route: {p.get('public_route')}",
            f"- Repo strategy: {p['repo_strategy']}",
            f"- Deployment strategy: {p['deployment_strategy']}",
            f"- Safe to preview: {p['safe_to_preview']}",
            f"- Source: {p['source_location']}",
            f"- Next action: {p['next_action']}",
            ""
        ]
    REPORT_PATH.parent.mkdir(parents=True, exist_ok=True)
    REPORT_PATH.write_text("\n".join(lines), encoding="utf-8")
    print(f"Updated {REGISTRY_PATH}")
    print(f"Wrote {REPORT_PATH}")

if __name__ == "__main__":
    main()
