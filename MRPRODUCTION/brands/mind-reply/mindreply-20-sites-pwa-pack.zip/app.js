if("serviceWorker" in navigator){navigator.serviceWorker.register("/sw.js").catch(()=>{})}
function copyText(id){navigator.clipboard.writeText(document.getElementById(id).innerText).then(()=>alert("Copied"))}
