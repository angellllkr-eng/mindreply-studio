# MindReply 20-Site Static Production Pack

What this is:
- 20 static revenue surface starters under /sites/
- Agent Dock PWA under /agent-dock/
- Root index with all pages
- Static only: no backend, no secrets, no database

Fastest hosting options:
1. GitHub Pages: upload all files to a public repo, Settings > Pages > Deploy from branch > main > root.
2. Cloudflare Pages Direct Upload: upload this folder or zip as prebuilt static assets.
3. Tiiny Host / Static.app: upload the zip/folder if GitHub is too hard on phone.
4. Surge: run `surge . your-name.surge.sh` from this folder.

After URL exists:
- Replace hello@mindreply.com CTAs.
- Connect custom domain later.
- Add real forms/payments only after privacy/support/legal pages are ready.
